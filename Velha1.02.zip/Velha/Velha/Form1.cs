﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Velha
{
    public partial class Form1 : Form
    {
        string jogador = "X";
        int cont = 0, soma = 0, jogada = 0, pontosX = 0, pontosO = 0;
        int[] num =
        {
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0

        };
        //mensagens e ações quando o jogador X vence
        public void botaoX()
        {
            lblMensagem.Text = "Jogador X Venceu!";
            lblMensagem.Visible = true;
            jogador = "X";
            lblJogador.Text = jogador;
            pontosX++;
            lblPontosX.Text = pontosX.ToString();
            jogada = 0;

            num[0] = 0;
            num[1] = 0;
            num[2] = 0;
            num[3] = 0;
            num[4] = 0;
            num[5] = 0;
            num[6] = 0;
            num[7] = 0;
            num[8] = 0;

            btn1.Text = "";
            btn2.Text = "";
            btn3.Text = "";
            btn4.Text = "";
            btn5.Text = "";
            btn6.Text = "";
            btn7.Text = "";
            btn8.Text = "";
            btn9.Text = "";
            btn1.Enabled = true;
            btn2.Enabled = true;
            btn3.Enabled = true;
            btn4.Enabled = true;
            btn5.Enabled = true;
            btn6.Enabled = true;
            btn7.Enabled = true;
            btn8.Enabled = true;
            btn9.Enabled = true;
        }
        //mensagens e ações quando o jogador O vence
        public void botaoO()
        {
            lblMensagem.Text = "Jogador O Venceu!";
            lblMensagem.Visible = true;
            jogador = "X";
            lblJogador.Text = jogador;
            pontosO++;
            lblPontosO.Text = pontosO.ToString();
            jogada = 0;

            num[0] = 0;
            num[1] = 0;
            num[2] = 0;
            num[3] = 0;
            num[4] = 0;
            num[5] = 0;
            num[6] = 0;
            num[7] = 0;
            num[8] = 0;

            btn1.Text = "";
            btn2.Text = "";
            btn3.Text = "";
            btn4.Text = "";
            btn5.Text = "";
            btn6.Text = "";
            btn7.Text = "";
            btn8.Text = "";
            btn9.Text = "";
            btn1.Enabled = true;
            btn2.Enabled = true;
            btn3.Enabled = true;
            btn4.Enabled = true;
            btn5.Enabled = true;
            btn6.Enabled = true;
            btn7.Enabled = true;
            btn8.Enabled = true;
            btn9.Enabled = true;
        }
        //logica para deciddir os vencedores
        public void vencedor()
        {
            if (num[0] + num[1] + num[2] == 3 ||
                num[3] + num[4] + num[5] == 3 ||
                num[2] + num[4] + num[6] == 3 ||
                num[1] + num[4] + num[7] == 3 ||
                num[0] + num[3] + num[6] == 3 ||
                num[6] + num[7] + num[8] == 3 ||
                num[2] + num[5] + num[8] == 3 ||
                num[0] + num[4] + num[8] == 3)
            {
                botaoX();
            }
            else if (num[3] + num[4] + num[5] == -3 ||
                     num[2] + num[4] + num[6] == -3 ||
                     num[1] + num[4] + num[7] == -3 ||
                     num[0] + num[1] + num[2] == -3 ||
                     num[0] + num[3] + num[6] == -3 ||
                     num[6] + num[7] + num[8] == -3 ||
                     num[2] + num[5] + num[8] == -3 ||
                     num[0] + num[4] + num[8] == -3)
            {
                botaoO();
            }
        }

        //logica da velha no jogo
        public void jogoVelha()
        {
            if (jogada == 7)
            {
                if (soma == 1 &&
                    num[0] + num[1] != 2 &&
                    num[0] + num[2] != 2 &&
                    num[0] + num[3] != 2 &&
                    num[0] + num[4] != 2 &&
                    num[0] + num[6] != 2 &&
                    num[0] + num[8] != 2 &&
                    num[1] + num[2] != 2 &&
                    num[1] + num[4] != 2 &&
                    num[1] + num[7] != 2 &&
                    num[2] + num[4] != 2 &&
                    num[2] + num[5] != 2 &&
                    num[2] + num[6] != 2 &&
                    num[2] + num[8] != 2 &&
                    num[3] + num[4] != 2 &&
                    num[3] + num[5] != 2 &&
                    num[3] + num[6] != 2 &&
                    num[4] + num[5] != 2 &&
                    num[4] + num[6] != 2 &&
                    num[4] + num[7] != 2 &&
                    num[4] + num[8] != 2 &&
                    num[5] + num[8] != 2 &&
                    num[6] + num[7] != 2 &&
                    num[6] + num[8] != 2 &&
                    num[7] + num[8] != 2)
                {
                    lblMensagem.Text = "VELHA";
                    lblMensagem.Visible = true;

                    jogador = "X";
                    lblJogador.Text = jogador;
                    jogada = 0;

                    num[0] = 0;
                    num[1] = 0;
                    num[2] = 0;
                    num[3] = 0;
                    num[4] = 0;
                    num[5] = 0;
                    num[6] = 0;
                    num[7] = 0;
                    num[8] = 0;

                    btn1.Text = "";
                    btn2.Text = "";
                    btn3.Text = "";
                    btn4.Text = "";
                    btn5.Text = "";
                    btn6.Text = "";
                    btn7.Text = "";
                    btn8.Text = "";
                    btn9.Text = "";
                    btn1.Enabled = true;
                    btn2.Enabled = true;
                    btn3.Enabled = true;
                    btn4.Enabled = true;
                    btn5.Enabled = true;
                    btn6.Enabled = true;
                    btn7.Enabled = true;
                    btn8.Enabled = true;
                    btn9.Enabled = true;
                }
                if (soma == -1 &&
                    num[0] + num[1] != -2 &&
                    num[0] + num[2] != -2 &&
                    num[0] + num[3] != -2 &&
                    num[0] + num[4] != -2 &&
                    num[0] + num[6] != -2 &&
                    num[0] + num[8] != -2 &&
                    num[1] + num[2] != -2 &&
                    num[1] + num[4] != -2 &&
                    num[1] + num[7] != -2 &&
                    num[2] + num[4] != -2 &&
                    num[2] + num[5] != -2 &&
                    num[2] + num[6] != -2 &&
                    num[2] + num[8] != -2 &&
                    num[3] + num[4] != -2 &&
                    num[3] + num[5] != -2 &&
                    num[3] + num[6] != -2 &&
                    num[4] + num[5] != -2 &&
                    num[4] + num[6] != -2 &&
                    num[4] + num[7] != -2 &&
                    num[4] + num[8] != -2 &&
                    num[5] + num[8] != -2 &&
                    num[6] + num[7] != -2 &&
                    num[6] + num[8] != -2 &&
                    num[7] + num[8] != -2)
                {
                    lblMensagem.Text = "VELHA";
                    lblMensagem.Visible = true;

                    jogador = "X";
                    lblJogador.Text = jogador;
                    jogada = 0;

                    num[0] = 0;
                    num[1] = 0;
                    num[2] = 0;
                    num[3] = 0;
                    num[4] = 0;
                    num[5] = 0;
                    num[6] = 0;
                    num[7] = 0;
                    num[8] = 0;

                    btn1.Text = "";
                    btn2.Text = "";
                    btn3.Text = "";
                    btn4.Text = "";
                    btn5.Text = "";
                    btn6.Text = "";
                    btn7.Text = "";
                    btn8.Text = "";
                    btn9.Text = "";
                    btn1.Enabled = true;
                    btn2.Enabled = true;
                    btn3.Enabled = true;
                    btn4.Enabled = true;
                    btn5.Enabled = true;
                    btn6.Enabled = true;
                    btn7.Enabled = true;
                    btn8.Enabled = true;
                    btn9.Enabled = true;
                }
            }
            if (jogada == 8)
            {
                if (soma == 0 &&
                    num[0] + num[1] == 2 ||
                    num[0] + num[2] == 2 ||
                    num[0] + num[3] == 2 ||
                    num[0] + num[4] == 2 ||
                    num[0] + num[6] == 2 ||
                    num[0] + num[8] == 2 ||
                    num[1] + num[2] == 2 ||
                    num[1] + num[4] == 2 ||
                    num[1] + num[7] == 2 ||
                    num[2] + num[4] == 2 ||
                    num[2] + num[5] == 2 ||
                    num[2] + num[6] == 2 ||
                    num[2] + num[8] == 2 ||
                    num[3] + num[4] == 2 ||
                    num[3] + num[5] == 2 ||
                    num[3] + num[6] == 2 ||
                    num[4] + num[5] == 2 ||
                    num[4] + num[6] == 2 ||
                    num[4] + num[7] == 2 ||
                    num[4] + num[8] == 2 ||
                    num[5] + num[8] == 2 ||
                    num[6] + num[7] == 2 ||
                    num[6] + num[8] == 2 ||
                    num[7] + num[8] == 2 ||
                    num[0] + num[1] == -2 ||
                    num[0] + num[2] == -2 ||
                    num[0] + num[3] == -2 ||
                    num[0] + num[4] == -2 ||
                    num[0] + num[6] == -2 ||
                    num[0] + num[8] == -2 ||
                    num[1] + num[2] == -2 ||
                    num[1] + num[4] == -2 ||
                    num[1] + num[7] == -2 ||
                    num[2] + num[4] == -2 ||
                    num[2] + num[5] == -2 ||
                    num[2] + num[6] == -2 ||
                    num[2] + num[8] == -2 ||
                    num[3] + num[4] == -2 ||
                    num[3] + num[5] == -2 ||
                    num[3] + num[6] == -2 ||
                    num[4] + num[5] == -2 ||
                    num[4] + num[6] == -2 ||
                    num[4] + num[7] == -2 ||
                    num[4] + num[8] == -2 ||
                    num[5] + num[8] == -2 ||
                    num[6] + num[7] == -2 ||
                    num[6] + num[8] == -2 ||
                    num[7] + num[8] == -2)
                {
                    lblMensagem.Text = "VELHA";
                    lblMensagem.Visible = true;

                    jogador = "X";
                    lblJogador.Text = jogador;
                    jogada = 0;

                    num[0] = 0;
                    num[1] = 0;
                    num[2] = 0;
                    num[3] = 0;
                    num[4] = 0;
                    num[5] = 0;
                    num[6] = 0;
                    num[7] = 0;
                    num[8] = 0;

                    btn1.Text = "";
                    btn2.Text = "";
                    btn3.Text = "";
                    btn4.Text = "";
                    btn5.Text = "";
                    btn6.Text = "";
                    btn7.Text = "";
                    btn8.Text = "";
                    btn9.Text = "";
                    btn1.Enabled = true;
                    btn2.Enabled = true;
                    btn3.Enabled = true;
                    btn4.Enabled = true;
                    btn5.Enabled = true;
                    btn6.Enabled = true;
                    btn7.Enabled = true;
                    btn8.Enabled = true;
                    btn9.Enabled = true;
                }


            }
            if (jogada == 9)
            {
                if (soma == 1 || soma == -1)
                {
                    lblMensagem.Text = "VELHA";
                    lblMensagem.Visible = true;

                    jogador = "X";
                    lblJogador.Text = jogador;
                    jogada = 0;

                    num[0] = 0;
                    num[1] = 0;
                    num[2] = 0;
                    num[3] = 0;
                    num[4] = 0;
                    num[5] = 0;
                    num[6] = 0;
                    num[7] = 0;
                    num[8] = 0;

                    btn1.Text = "";
                    btn2.Text = "";
                    btn3.Text = "";
                    btn4.Text = "";
                    btn5.Text = "";
                    btn6.Text = "";
                    btn7.Text = "";
                    btn8.Text = "";
                    btn9.Text = "";
                    btn1.Enabled = true;
                    btn2.Enabled = true;
                    btn3.Enabled = true;
                    btn4.Enabled = true;
                    btn5.Enabled = true;
                    btn6.Enabled = true;
                    btn7.Enabled = true;
                    btn8.Enabled = true;
                    btn9.Enabled = true;
                }
            }
        }
        public Form1()
        {
            InitializeComponent();
        }
        //inicia os botões e suas funções
        private void btn1_Click(object sender, EventArgs e)
        {
            jogada++;
            btn1.Text = jogador;
            if (jogador == "X")
            {
                num[0] = 1;
                jogador = "O";
            }
            else
            {
                num[0] = -1;
                jogador = "X";
            }
            lblJogador.Text = jogador;
            btn1.Enabled = false;

            soma = num[0] + num[1] + num[2] + num[3] + num[4] + num[5] + num[6] + num[7] + num[8];

            vencedor();

            jogoVelha();
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            jogada++;
            btn2.Text = jogador;
            if (jogador == "X")
            {
                num[1] = 1;
                jogador = "O";
            }
            else
            {
                num[1] = -1;
                jogador = "X";
            }
            lblJogador.Text = jogador;
            btn2.Enabled = false;

            soma = num[0] + num[1] + num[2] + num[3] + num[4] + num[5] + num[6] + num[7] + num[8];

            vencedor();

            jogoVelha();

        }

        private void btn3_Click(object sender, EventArgs e)
        {
            jogada++;
            btn3.Text = jogador;
            if (jogador == "X")
            {
                num[2] = 1;
                jogador = "O";
            }
            else
            {
                num[2] = -1;
                jogador = "X";
            }
            lblJogador.Text = jogador;
            btn3.Enabled = false;

            soma = num[0] + num[1] + num[2] + num[3] + num[4] + num[5] + num[6] + num[7] + num[8];

            vencedor();

            jogoVelha();

        }

        private void btn4_Click(object sender, EventArgs e)
        {
            jogada++;
            btn4.Text = jogador;
            if (jogador == "X")
            {
                num[3] = 1;
                jogador = "O";
            }
            else
            {
                num[3] = -1;
                jogador = "X";
            }
            lblJogador.Text = jogador;
            btn4.Enabled = false;

            soma = num[0] + num[1] + num[2] + num[3] + num[4] + num[5] + num[6] + num[7] + num[8];

            vencedor();

            jogoVelha();
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            jogada++;
            btn5.Text = jogador;
            if (jogador == "X")
            {
                num[4] = 1;
                jogador = "O";
            }
            else
            {
                num[4] = -1;
                jogador = "X";
            }
            lblJogador.Text = jogador;
            btn5.Enabled = false;

            soma = num[0] + num[1] + num[2] + num[3] + num[4] + num[5] + num[6] + num[7] + num[8];

            vencedor();

            jogoVelha();

        }

        private void btn6_Click(object sender, EventArgs e)
        {
            jogada++;
            btn6.Text = jogador;
            if (jogador == "X")
            {
                num[5] = 1;
                jogador = "O";
            }
            else
            {
                num[5] = -1;
                jogador = "X";
            }
            lblJogador.Text = jogador;
            btn6.Enabled = false;

            soma = num[0] + num[1] + num[2] + num[3] + num[4] + num[5] + num[6] + num[7] + num[8];

            vencedor();

            jogoVelha();

        }

        private void btn7_Click(object sender, EventArgs e)
        {
            jogada++;
            btn7.Text = jogador;
            if (jogador == "X")
            {
                num[6] = 1;
                jogador = "O";
            }
            else
            {
                num[6] = -1;
                jogador = "X";
            }
            lblJogador.Text = jogador;
            btn7.Enabled = false;

            soma = num[0] + num[1] + num[2] + num[3] + num[4] + num[5] + num[6] + num[7] + num[8];

            vencedor();

            jogoVelha();

        }

        private void btn8_Click(object sender, EventArgs e)
        {
            jogada++;
            btn8.Text = jogador;
            if (jogador == "X")
            {
                num[7] = 1;
                jogador = "O";
            }
            else
            {
                num[7] = -1;
                jogador = "X";
            }
            lblJogador.Text = jogador;
            btn8.Enabled = false;

            soma = num[0] + num[1] + num[2] + num[3] + num[4] + num[5] + num[6] + num[7] + num[8];

            vencedor();

            jogoVelha();

        }

        private void btn9_Click(object sender, EventArgs e)
        {
            jogada++;
            btn9.Text = jogador;
            if (jogador == "X")
            {
                num[8] = 1;
                jogador = "O";
            }
            else
            {
                num[8] = -1;
                jogador = "X";
            }
            lblJogador.Text = jogador;
            btn9.Enabled = false;

            soma = num[0] + num[1] + num[2] + num[3] + num[4] + num[5] + num[6] + num[7] + num[8];

            vencedor();

            jogoVelha();

        }
        //ao clicar na mensagem do fim de jogo
        private void lblMensagem_Click(object sender, EventArgs e)
        {

            lblMensagem.Visible = false;
        }
        //links de doação caso alquem quera me dar uma força
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://pag.ae/bccfPHY");
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.patreon.com/bePatron?patAmt=5&u=799586");
        }
        //sobre o jogo, quem criou, tentar ganhar mais alguns inscritos
        private void lblSobreJogo_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Jogo feito em C Sharp pelo Jonas\n      Visite o canal no youtube:\n             Jonas Diferencial", "Sobre o jogo");
        }



    }
}

