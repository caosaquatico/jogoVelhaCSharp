﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Velha
{
    public partial class Form1 : Form
    {
        string jogador = "X";
        int cont = 0, soma = 0, jogada = 0, pontosX=0, pontosO=0;
        int[] num =
        {
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0

        };
        public void botaoX()
        {
            lblMensagem.Text = "Jogador X Venceu!";
            lblMensagem.Visible = true;

             //MessageBox.Show("O jogador X vencedor!!");
             jogador = "X";
            lblJogador.Text = jogador;
            pontosX++;
            lblPontosX.Text = pontosX.ToString();
            jogada = 0;

            num[0] = 0;
            num[1] = 0;
            num[2] = 0;
            num[3] = 0;
            num[4] = 0;
            num[5] = 0;
            num[6] = 0;
            num[7] = 0;
            num[8] = 0;

            btn1.Text = "";
            btn2.Text = "";
            btn3.Text = "";
            btn4.Text = "";
            btn5.Text = "";
            btn6.Text = "";
            btn7.Text = "";
            btn8.Text = "";
            btn9.Text = "";
            btn1.Enabled = true;
            btn2.Enabled = true;
            btn3.Enabled = true;
            btn4.Enabled = true;
            btn5.Enabled = true;
            btn6.Enabled = true;
            btn7.Enabled = true;
            btn8.Enabled = true;
            btn9.Enabled = true;
        }
        public void botaoO()
        {
            lblMensagem.Text = "Jogador O Venceu!";
            lblMensagem.Visible = true;
            //MessageBox.Show("O jogador O vencedor!!");
            jogador = "X";
            lblJogador.Text = jogador;
            pontosO++;
            lblPontosO.Text = pontosO.ToString();
            jogada = 0;

            num[0] = 0;
            num[1] = 0;
            num[2] = 0;
            num[3] = 0;
            num[4] = 0;
            num[5] = 0;
            num[6] = 0;
            num[7] = 0;
            num[8] = 0;

            btn1.Text = "";
            btn2.Text = "";
            btn3.Text = "";
            btn4.Text = "";
            btn5.Text = "";
            btn6.Text = "";
            btn7.Text = "";
            btn8.Text = "";
            btn9.Text = "";
            btn1.Enabled = true;
            btn2.Enabled = true;
            btn3.Enabled = true;
            btn4.Enabled = true;
            btn5.Enabled = true;
            btn6.Enabled = true;
            btn7.Enabled = true;
            btn8.Enabled = true;
            btn9.Enabled = true;
        }
        public void vencedor()
        {
            if (num[0] + num[1] + num[2] == 3 || num[3] + num[4] + num[5] == 3 || num[2] + num[4] + num[6] == 3 ||
        num[1] + num[4] + num[7] == 3 || num[0] + num[3] + num[6] == 3 || num[6] + num[7] + num[8] == 3 ||
        num[2] + num[5] + num[8] == 3 || num[0] + num[4] + num[8] == 3)
            {
                botaoX();
            }
            else if (num[3] + num[4] + num[5] == -3 || num[2] + num[4] + num[6] == -3 ||
                num[1] + num[4] + num[7] == -3 || num[0] + num[1] + num[2] == -3 ||
                num[0] + num[3] + num[6] == -3 || num[6] + num[7] + num[8] == -3 ||
                num[2] + num[5] + num[8] == -3 || num[0] + num[4] + num[8] == -3)
            {
                botaoO();
            }
        }
        public void velha()
        {
            lblMensagem.Text = "VELHA";
            lblMensagem.Visible = true;
            //MessageBox.Show("Velha");
            jogador = "X";
            lblJogador.Text = jogador;
            jogada = 0;

            num[0] = 0;
            num[1] = 0;
            num[2] = 0;
            num[3] = 0;
            num[4] = 0;
            num[5] = 0;
            num[6] = 0;
            num[7] = 0;
            num[8] = 0;

            btn1.Text = "";
            btn2.Text = "";
            btn3.Text = "";
            btn4.Text = "";
            btn5.Text = "";
            btn6.Text = "";
            btn7.Text = "";
            btn8.Text = "";
            btn9.Text = "";
            btn1.Enabled = true;
            btn2.Enabled = true;
            btn3.Enabled = true;
            btn4.Enabled = true;
            btn5.Enabled = true;
            btn6.Enabled = true;
            btn7.Enabled = true;
            btn8.Enabled = true;
            btn9.Enabled = true;
        }
        public void jogoVelha()
        {
            if (jogada == 7)
                if (soma == 1 && num[0] + num[4] != 2 && num[2] + num[4] != 2 && num[3] + num[4] != 2 && num[5] + num[4] != 2)
                {
                    velha();
                }
                else if (soma == -1 && num[0] + num[4] != -2 && num[2] + num[4] != -2 && num[3] + num[4] != -2 && num[5] + num[4] != -2)
                {
                    velha();
                }
            if (jogada == 9)
            {
                if (soma == 1 || soma == -1)
                {
                    velha();
                }
            }
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            btn1.Text = jogador;

            if (jogador == "X")
            {
                num[0] = 1;
                jogador = "O";
            }
            else
            {
                num[0] = -1;
                jogador = "X";
            }
            lblJogador.Text = jogador;
            btn1.Enabled = false;
            jogada++;
            soma = num[0] + num[1] + num[2] + num[3] + num[4] + num[5] + num[6] + num[7] + num[8];

            vencedor();

            jogoVelha();
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            btn2.Text = jogador;
            if (jogador == "X")
            {
                num[1] = 1;
                jogador = "O";
            }
            else
            {
                num[1] = -1;
                jogador = "X";
            }
            lblJogador.Text = jogador;
            btn2.Enabled = false;
            jogada++;
            soma = num[0] + num[1] + num[2] + num[3] + num[4] + num[5] + num[6] + num[7] + num[8];

            vencedor();

            jogoVelha();

        }

        private void btn3_Click(object sender, EventArgs e)
        {
            btn3.Text = jogador;
            if (jogador == "X")
            {
                num[2] = 1;
                jogador = "O";
            }
            else
            {
                num[2] = -1;
                jogador = "X";
            }
            lblJogador.Text = jogador;
            btn3.Enabled = false;
            jogada++;
            soma = num[0] + num[1] + num[2] + num[3] + num[4] + num[5] + num[6] + num[7] + num[8];

            vencedor();

            jogoVelha();

        }

        private void btn4_Click(object sender, EventArgs e)
        {
            btn4.Text = jogador;
            if (jogador == "X")
            {
                num[3] = 1;
                jogador = "O";
            }
            else
            {
                num[3] = -1;
                jogador = "X";
            }
            lblJogador.Text = jogador;
            btn4.Enabled = false;
            jogada++;
            soma = num[0] + num[1] + num[2] + num[3] + num[4] + num[5] + num[6] + num[7] + num[8];

            vencedor();

            jogoVelha();
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            btn5.Text = jogador;
            if (jogador == "X")
            {
                num[4] = 1;
                jogador = "O";
            }
            else
            {
                num[4] = -1;
                jogador = "X";
            }
            lblJogador.Text = jogador;
            btn5.Enabled = false;
            jogada++;
            soma = num[0] + num[1] + num[2] + num[3] + num[4] + num[5] + num[6] + num[7] + num[8];

            vencedor();

            jogoVelha();

        }

        private void lblMensagem_Click(object sender, EventArgs e)
        {
            
            lblMensagem.Visible = false;
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            btn6.Text = jogador;
            if (jogador == "X")
            {
                num[5] = 1;
                jogador = "O";
            }
            else
            {
                num[5] = -1;
                jogador = "X";
            }
            lblJogador.Text = jogador;
            btn6.Enabled = false;
            jogada++;
            soma = num[0] + num[1] + num[2] + num[3] + num[4] + num[5] + num[6] + num[7] + num[8];

            vencedor();

            jogoVelha();

        }

        private void btn7_Click(object sender, EventArgs e)
        {
            btn7.Text = jogador;
            if (jogador == "X")
            {
                num[6] = 1;
                jogador = "O";
            }
            else
            {
                num[6] = -1;
                jogador = "X";
            }
            lblJogador.Text = jogador;
            btn7.Enabled = false;
            jogada++;
            soma = num[0] + num[1] + num[2] + num[3] + num[4] + num[5] + num[6] + num[7] + num[8];

            vencedor();

            jogoVelha();

        }

        private void btn8_Click(object sender, EventArgs e)
        {
            btn8.Text = jogador;
            if (jogador == "X")
            {
                num[7] = 1;
                jogador = "O";
            }
            else
            {
                num[7] = -1;
                jogador = "X";
            }
            lblJogador.Text = jogador;
            btn8.Enabled = false;
            jogada++;
            soma = num[0] + num[1] + num[2] + num[3] + num[4] + num[5] + num[6] + num[7] + num[8];

            vencedor();

            jogoVelha();

        }

        private void btn9_Click(object sender, EventArgs e)
        {
            btn9.Text = jogador;
            if (jogador == "X")
            {
                num[8] = 1;
                jogador = "O";
            }
            else
            {
                num[8] = -1;
                jogador = "X";
            }
            lblJogador.Text = jogador;
            btn9.Enabled = false;
            jogada++;
            soma = num[0] + num[1] + num[2] + num[3] + num[4] + num[5] + num[6] + num[7] + num[8];

            vencedor();

            jogoVelha();

        }


    }
}

